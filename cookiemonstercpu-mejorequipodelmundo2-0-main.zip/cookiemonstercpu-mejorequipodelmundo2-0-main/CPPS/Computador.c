#include "../headers/Computador.h"
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include "impreProgramas.c"

extern void copiar(int*,int);
extern void obtenerOverflowFlag(int*);
extern void obtenerZeroFlag(int*);
extern void obtenerSingFlag(int*);
extern void obtenerCarryFlag(int*);
extern void multiplicar(int*,int,int);
extern void disminuir(int*);
extern void aumentar(int*);
extern void comparar(int,int,int*,int*,int*,int*);
extern void saltoNoIgual(int, int, int*,int);
extern void saltoIgual(int, int, int*,int);
extern void saltoMayorIgual(int, int, int*,int);
extern void sumar(int*,int);
extern void DAEMLM(int*,int,int);
void iniciarComputador(struct Computador *computador){
    computador->PC = 0;
    computador->IR = 0;
    computador->OF = 0;
    computador->ZF = 0;
    computador->SF = 0;
    computador->CF = 0;
    computador->SI = 0;
    computador->DI = 0;
    computador->EAX = 0;
    computador->EBX = 0;
    computador->ECX = 0;
    computador->EDX = 0;
    computador->contFetch = 0;
    computador->autoMatic = 0;
    computador->encendido = 0;
    for (int i = 0; i < 30; i++)
    {
        computador->memoria[i] = 0;
    }
}
/*=========================================
Objetivo: Limpiar una parte especifica de la interfaz
Input: win(ventana),computador(estructura),inicio(inicio Y),final(final Y),pos(inicio X),cantEspacios(largo de la fila)
Output: Area especificada sin datos en pantalla
=========================================*/
void limpiarArea(WINDOW * win, struct Computador *computador,int inicio, int final, int pos, int cantEspacios){
    int copia = pos;
    for (int i = inicio; i < final; i++)
    {
        for (int j = 0; j < cantEspacios; j++)
        {
            mvwprintw(win,i,pos," ");
            pos++;
        }
        pos = copia;
    }
}
/*=========================================
Objetivo: Imprime el codigo de la instruccion en el IR
Input: num(numero de la instruccion), win(ventana)
Output: Numero de la instruccion en pantalla
=========================================*/
void printInstruccion(int num, WINDOW  * win){
    int x = win->_maxx/2+21+4;
    int y = 9;
    int arregloDigitos [4];
    for (int i = 0; i < 4; i++){
        arregloDigitos[i]=0;
    }
    for (int i = 0; num > 0; i++){
        arregloDigitos[i] = num%2;
        num = num/2;
    }
    for (int i =3; i >= 0; i--){
        if(arregloDigitos[i]==0){
            mvwprintw(win,y,x,"0");
        }else{
            mvwprintw(win,y,x,"1");
        }
        x++;
    }
}
/*=========================================
Objetivo: Imprime la direccion utilizada en el IR
Input: adx(Numero para posicion),num(numero de la direccion),win(ventana)
Output: Direccion utilizada para el IR en pantalla
=========================================*/
void printDirecction(int adX,int num, WINDOW  * win){
    int x = win->_maxx/2+adX+4;
    int y = 9;
    int arregloDigitos [6];
    for (int i = 0; i < 6; i++){
        arregloDigitos[i]=0;
    }
    for (int i = 0; num > 0; i++){
        arregloDigitos[i] = num%2;
        num = num/2;
    }
    for (int i =5; i >= 0; i--){
        if(arregloDigitos[i]==0){
            mvwprintw(win,y,x,"0");
        }else{
            mvwprintw(win,y,x,"1");
        }
        x++;
    }
}
/*=========================================
Objetivo: Imprime la estapa fetch y sus respectivos valores
Input: win(ventana),computador(estructura),instruccion(instruccion a realizar),fuente(direccion fuente),destino(direccion destino)
Output: Etapa fetch y sus valores en pantalla
=========================================*/
void imprimirFetch(WINDOW * win, struct Computador *computador,int instruccion, int fuente, int destino){
    limpiarArea(win,computador,win->_maxy/2+3,win->_maxy/8*6,win->_maxx/2+21,23); 
    mvwprintw(win,win->_maxy/2+3,win->_maxx/2+21,"Fetch");  
    printInstruccion(instruccion,win);
    printDirecction(25,fuente,win);
    printDirecction(31,destino,win);
    sleep(1);
    wrefresh(win);
}
/*=========================================
Objetivo: Imprime la segunda y tercera parte del ciclo fetch
Input: win(ventana),computador(estructura)
Output: Segunda y tercera etapa del ciclo fetch en pantalla
=========================================*/
void imprimirEtapaFetch(WINDOW * win, struct Computador *computador){
    int etapa = 0;
    while(etapa < 2){
        limpiarArea(win,computador,win->_maxy/2+3,win->_maxy/8*6,win->_maxx/2+21,23); //Limpia la parte del fetch
        sleep(1);
        switch (etapa)
        {
        case 0:
            mvwprintw(win,win->_maxy/2+3,win->_maxx/2+21,"Decodificar");  
            break;
        case 1:
            mvwprintw(win,win->_maxy/2+3,win->_maxx/2+21,"Ejecutar");  
            break;  
        default:
            break;
        }
        etapa++;
        wrefresh(win);
    }
}
/*=========================================
Objetivo: Imprime en pantalla el menu para ejecutar un programa
Input: win(ventana en la que se imprime), computador(estructura)
Output: Menu de ejecucion de programa desplegado en pantalla
=========================================*/
void menuPrograma(WINDOW * win, struct Computador *computador){
    int regY = win->_maxy/2+3;
    int regX = win->_maxx/4 + 20;
    limpiarArea(win,computador,regY,30,regX,28); //Limpia el menu
    wattron(win,COLOR_PAIR(2));
    mvwprintw(win,regY,regX,"1- Paso siguiente");
    wattroff(win,COLOR_PAIR(2));
    mvwprintw(win,regY+1,regX,"2- Salir");
    mvwprintw(win,regY+2,regX,"0- Automatico");
    refresh();

}
/*=========================================
Objetivo: Imprime el digito
Input: x(posicion en X),y(posicion en Y),num(numero a imprimir),win(ventana)
Output: Digito en pantalla
=========================================*/
void printDigit(int x , int y , int num, WINDOW  * win){
    int arregloDigitos [16];
    for (int i = 0; i < 16; i++){
        arregloDigitos[i]=0;
    }
    for (int i = 0; num > 0; i++){
        arregloDigitos[i] = num%2;
        num = num/2;
    }
    for (int i =15; i >= 0; i--){
        if(arregloDigitos[i]==0){
            mvwprintw(win,y,x,"0");
        }else{
            mvwprintw(win,y,x,"1");
        }
        x++;
    }
}
/*=========================================
Objetivo: Dibuja en pantalla una seccion
Input: win(ventana),y1(inicio en Y),x1(inicio en X),y2(final en Y), x2(final en X),title(titulo de la seccion),parDeColor(color del rectangulo)
Output: Seccion del color ingresado en pantalla
=========================================*/
void rectangle(WINDOW * win,int y1, int x1, int y2, int x2,char title[50], int parDeColor)
{
    wattron(win,COLOR_PAIR(parDeColor));
    mvwhline(win,y1, x1, 0, x2-x1);
    mvwhline(win,y2, x1, 0, x2-x1);
    mvwvline(win,y1, x1, 0, y2-y1);
    mvwvline(win,y1, x2, 0, y2-y1);
    mvwaddch(win,y1, x1, ACS_ULCORNER);
    mvwaddch(win,y2, x1, ACS_LLCORNER);
    mvwaddch(win,y1, x2, ACS_URCORNER);
    mvwaddch(win,y2, x2, ACS_LRCORNER);
    wattroff(win,COLOR_PAIR(parDeColor));
    wattron(win,COLOR_PAIR(1));
    mvwprintw(win,y1,x1+2,title);
    wattron(win,COLOR_PAIR(1));
}
/*=========================================
Objetivo: Se dibujan todas las secciones del programa
Input: win(ventana),maxY(tamanno de ventana en Y), maxX(tamanno de ventana en X)
Output: Secciones de la interfaz desplegada en pantalla
=========================================*/
void dibujarInterfaz(WINDOW * win,int maxY,int maxX){
    start_color();
    initColors();
    initPairs();
    rectangle(win,1,1,maxY-2,maxX/4+17,"Entrada",parIO);  //Dibuja entrada de datos
    rectangle(win,1,maxX/4+18,maxY/2,maxX/2+18,"Salida",parIO);  //Dibuja salida de datos
    rectangle(win,1,maxX/2+19,maxY/2,maxX/4*3+9,"Registros",parRegs);  //Dibuja registros
    rectangle(win,maxY/8*6+1,maxX/2+19,maxY-2,maxX/4*3+9,"Flags",parFlags);  //Dibuja flags

    rectangle(win,maxY/2+1,maxX/4+18,maxY-2,maxX/2+18,"Menu",parMenu); //Dibuja en menu

    rectangle(win,maxY/2+1,maxX/2+19,maxY/8*6,maxX/4*3+9,"Etapa Fetch",parFetch);  //Dibuja cicloFetch
    rectangle(win,1,maxX/4*3+10,maxY-2,maxX-2,"Memoria",parMem);  //Dibuja Memoria

}
/*=========================================
Objetivo: Funcion auxiliar para imprimir
Input: x(inicio en X), y(inicio en Y), numero(valor del registro), texto(nombre del registro),win(ventana)
Output: impresion de un texto y un valor
=========================================*/
void imprimirDato(int x, int y, int numero,char texto[50] ,WINDOW * win){
    mvwprintw(win,y,x,texto);
    printDigit(x+4,y,numero,win);

}
/*=========================================
Objetivo: Imprime los registros del CPU y su valor
Input: win(ventana en la que se dibuja),computador(estructura)
Output: Registros y su valor desplegados en pantalla
=========================================*/
void mostrarRegistros(WINDOW * win,struct Computador *computador){
    int regX = win->_maxx/2+21;
    int regY = 4;
    imprimirDato(regX,regY,computador->EAX,"AX: ",win);
    regY ++;
    imprimirDato(regX,regY,computador->EBX,"BX: ",win);
    regY ++;
    imprimirDato(regX,regY,computador->ECX,"CX: ",win);
    regY ++;
    imprimirDato(regX,regY,computador->EDX,"DX: ",win);
    regY++;
    imprimirDato(regX,regY,computador->PC,"PC: ",win);
    regY++;
    if(computador->IR == 0){
        imprimirDato(regX,regY,computador->IR,"IR: ",win);
    }
    regY++;
    imprimirDato(regX,regY,computador->DI,"DI: ",win);
    regY++;
    imprimirDato(regX,regY,computador->SI,"SI: ",win);
}
/*=========================================
Objetivo: Muestra las banderas del CPU y su valor
Input: win(ventana en la que se dibuja),computador(estructura de donde se obtiene el valor)
Output: Banderas y su respectivos valores en pantalla
=========================================*/
void mostrarFlags(WINDOW * win,struct Computador *computador){
    int regX = win->_maxx/2+21;
    int regY = win->_maxy/8*6+2;
    imprimirDato(regX,regY,computador->OF,"OF: ",win);
    regY ++;
    imprimirDato(regX,regY,computador->ZF,"ZF: ",win);
    regY ++;
    imprimirDato(regX,regY,computador->SF,"SF: ",win);
    regY ++;
    imprimirDato(regX,regY,computador->CF,"CF: ",win);
}
/*=========================================
Objetivo: Imprime en pantalla las celdas de memoria
Input: win(ventana en la que se dibuja),computador(estructura de donde se obtiene informacion)
Output: Celdas de memoria y su valor desplegadas en pantalla
=========================================*/
void mostrarMemoria(WINDOW * win,struct Computador *computador){
    int regX = win->_maxx/4*3+12;
    int regY = 2;
    for (int i = 0; i < 30; i++)
    {
        mvwprintw(win,regY+i,regX,"%d : ",i);
        imprimirDato(regX+1,regY+i,computador->memoria[i],"",win);

    }

}
/*=========================================
Objetivo: Muestra los datos de las secciones de registros,banderas y memoria
Input: win(ventana donde de despliegan),computador(estructura de donde se obtiene informacion)
Output: Secciones desplegadas en pantalla
=========================================*/
void mostrarDatos(WINDOW * win, struct Computador *computador){
    mostrarRegistros(win,computador);
    mostrarFlags(win,computador);
    mostrarMemoria(win,computador);
}
/*=========================================
Objetivo: Realiza las instrucciones del primer programa
Input: win(ventana donde de despliegan),computador(estructura de donde se obtiene informacion)
Output: Ejecucion del primer programa
=========================================*/
void recibirCadena(WINDOW * win, struct Computador *computador,int inicio){
    int ch = -1;
    int x = 0;
    while(1){
      mvwprintw(win,2,win->_maxx/4+40+x,"_");
      ch = wgetch(win);
      if(ch == 10){
        mvwprintw(win,2,win->_maxx/4+40+x," ");
        break;
      }
      computador->memoria[inicio] = ch;
      copiar(&computador->memoria[inicio],ch);
      mvwprintw(win,2,win->_maxx/4+40+x,"%c",ch);
      inicio++;
      x++;
    }
}
/*=========================================
Objetivo: Recibe un numero
Input: win(pantalla),computador(estructura),mx(posicion en X),my(posicion en Y)
Output: Numero en la posicion indicada
=========================================*/
int recibirNumero(WINDOW * win, struct Computador *computador,int mx,int my){
  char ch = -1;
  int res = 0;
  int x = 1+mx;
  while(1){
    mvwprintw(win,2+my,win->_maxx/4+36+x,"_");
    ch = wgetch(win);
    if(ch == 10){
      mvwprintw(win,2+my,win->_maxx/4+36+x," ");
      break;
    }
    if(ch >= 48 && ch <=57){
      res = res*10;
      res += ch-48;
      mvwprintw(win,2+my,win->_maxx/4+36+x,"%d",ch-48);
      wrefresh(win);
      x++;
    }
  }
  return res;
}
/*=========================================
Objetivo: Actualiza las banderas del CPU
Input: win(ventana),computador(estructura)
Output: Valor actual de las banderas en pantalla
=========================================*/
void actualizarFlags(WINDOW * win, struct Computador *computador){
  obtenerOverflowFlag(&computador->OF);
  obtenerZeroFlag(&computador->ZF);
  obtenerSingFlag(&computador->SF);
  obtenerCarryFlag(&computador->CF);
}
/*=========================================
Objetivo: Ejecuta las instrucciones del primer programa
Input: win(ventana),computador(estructura)
Output: Ejecucion del primer programa
=========================================*/
void ejecutarProgramaUno(WINDOW * win, struct Computador *computador){
    int ended = 0;
    int ch = 0;
    int anteriorX = -1;
    computador->PC = 1;
    while(!ended){
        switch (computador->PC){
            case 2:
                imprimirFetch(win,computador,0,0,1);
                copiar(&computador->memoria[0],1);
                actualizarFlags(win,computador);
                break;
            case 3:
                imprimirFetch(win,computador,9,0,0);
                mvwprintw(win,2,win->_maxx/4+20,"Ingrese el dato: ");
                actualizarFlags(win,computador);
                break;
            case 4:
                imprimirFetch(win,computador,13,30,0);
                mvwprintw(win,computador->PC+7,3,"->");
                mvwprintw(win,anteriorX,3,"  ");
                wrefresh(win);
                actualizarFlags(win,computador);
                copiar(&computador->memoria[1],recibirNumero(win,computador,0,0));
                break;
            case 6:
                imprimirFetch(win,computador,0,30,0);
                copiar(&computador->EAX,computador->memoria[1]);
                actualizarFlags(win,computador);
                break;
            case 7:
                imprimirFetch(win,computador,0,31,0);
                copiar(&computador->EBX,computador->memoria[0]);
                actualizarFlags(win,computador);
                break;
            case 8:
                imprimirFetch(win,computador,1,0,31);
                multiplicar(&computador->EAX,computador->EAX,computador->EBX);
                actualizarFlags(win,computador);
                break;
            case 9:
                imprimirFetch(win,computador,0,0,30);
                copiar(&computador->memoria[0],computador->EAX);
                actualizarFlags(win,computador);
                break;
            case 10:
                imprimirFetch(win,computador,0,30,0);
                copiar(&computador->EAX,computador->memoria[1]);
                actualizarFlags(win,computador);
                break;
            case 11:
                imprimirFetch(win,computador,2,30,0);
                disminuir(&computador->EAX);
                actualizarFlags(win,computador);
                break;
            case 12:
                imprimirFetch(win,computador,0,0,30);
                copiar(&computador->memoria[1],computador->EAX);
                actualizarFlags(win,computador);
                break;
            case 13:
                imprimirFetch(win,computador,4,30,0);
                comparar(computador->EAX,1,&computador->ZF,&computador->SF,&computador->CF,&computador->OF);
                break;
            case 14:
                imprimirFetch(win,computador,5,0,0);
                saltoNoIgual(computador->EAX,1,&computador->PC,5);
                break;
            case 16:
                imprimirFetch(win,computador,9,0,0);
                mvwprintw(win,3,win->_maxx/4+20,"El resultado es: ");
                break;
            case 17:
                imprimirFetch(win,computador,13,0,0);
                mvwprintw(win,3,win->_maxx/4+37,"%d",computador->memoria[0]);
                break;
            case 18:
                ended = 1;
                actualizarFlags(win,computador);
                break;
            default:
                break;
        }
        imprimirEtapaFetch(win,computador);
        mvwprintw(win,win->_maxy/2+3,win->_maxx/2+21,"Almacenar"); 
        sleep(1);
        mostrarDatos(win,computador);
        mvwprintw(win,computador->PC+7,3,"->");
        mvwprintw(win,anteriorX,3,"  ");
        anteriorX =computador->PC+7;
        wrefresh(win);
        if(ch != '0'){
          ch = wgetch(win);
          if(ch == '1'){
              computador->PC++;
          }else if( ch == '2'){
              mostrarDatos(win,computador);
              wrefresh(win);
              break;
          }
        }
        else{
          computador->PC++;
        }
    }
    iniciarComputador(computador);
    mostrarDatos(win,computador);
    wrefresh(win);
}
/*=========================================
Objetivo: Proceso general del primer programa
Input: win(ventana),computador(estructura)
Output: Proceso del primer programa realizado
=========================================*/
void programaUno(WINDOW * win, struct Computador *computador){
    computador->IR = 1;
    int regY = win->_maxy/2+3;
    int regX = win->_maxx/4 + 20;
    mostrarProgramaUno(win);
    menuPrograma(win,computador);
    wrefresh(win);
    ejecutarProgramaUno(win,computador);
    limpiarArea(win,computador,regY,30,regX,28);
    wrefresh(win);
}
/*=========================================
Objetivo: Muestra una cadena de texto
Input: win(ventana),computador(estructura)
Output: Cadena en pantalla
=========================================*/
void mostrarCadena(WINDOW * win, struct Computador *computador){
  int cont = 1;
  while(1){
    if(computador->memoria[cont]!=0){
      mvwprintw(win,3,win->_maxx/4+20+cont,"%c",computador->memoria[cont]);
    }
    else{
      break;
    }
    cont++;
  }
}
/*=========================================
Objetivo: Ejecuta las instrucciones del programa dos
Input: win(ventana),computador(estructura)
Output: Ejecucion del programa dos terminado
=========================================*/
void ejecutarProgramaDos(WINDOW * win, struct Computador *computador){
    int ended = 0;
    int ch = 0;
    int anteriorX = -1;
    computador->PC = 1;
    while(!ended){
        imprimirEtapaFetch(win,computador);
        switch (computador->PC){
            case 2:
                imprimirFetch(win,computador,9,0,0);
                mvwprintw(win,2,win->_maxx/4+20,"Ingrese una cadena: ");
                actualizarFlags(win,computador);
                break;
            case 3:
                imprimirFetch(win,computador,10,0,0);
                mvwprintw(win,computador->PC+6,3,"->");
                mvwprintw(win,anteriorX,3,"  ");
                wrefresh(win);
                recibirCadena(win,computador,1);
                actualizarFlags(win,computador);
                break;
            case 4:
                imprimirFetch(win,computador,9,0,30);
                copiar(&computador->EAX,1);
                break;
            case 6:
                imprimirFetch(win,computador,4,0,30);
                comparar(computador->memoria[computador->EAX],'a',&computador->ZF,&computador->SF,&computador->CF,&computador->OF);
                actualizarFlags(win,computador);
                break;
            case 7:
                imprimirFetch(win,computador,6,0,0);
                saltoMayorIgual(computador->memoria[computador->EAX],'a',&computador->PC,11);
                actualizarFlags(win,computador);
                break;
            case 8:
                imprimirFetch(win,computador,4,30,0);
                comparar(computador->memoria[computador->EAX],0,&computador->ZF,&computador->SF,&computador->CF,&computador->OF);
                actualizarFlags(win,computador);sleep(1);
        mvwprintw(win,win->_maxy/2+3,win->_maxx/2+21,"Almacenar");
                break;
            case 9:
                imprimirFetch(win,computador,14,0,0);
                saltoIgual(computador->memoria[computador->EAX],0,&computador->PC,14);
                actualizarFlags(win,computador);
                break;
            case 10:
                imprimirFetch(win,computador,7,0,30);
                sumar(&computador->memoria[computador->EAX],32);
                actualizarFlags(win,computador);
                break;
            case 12:
                imprimirFetch(win,computador,3,0,30);
                aumentar(&computador->EAX);
                break;
            case 13:
                imprimirFetch(win,computador,12,0,5);
               computador->PC = 5;
               break;
              break;
            case 15:
                imprimirFetch(win,computador,9,0,0);
                mostrarCadena(win,computador);
                break;
            case 17:
                mvwprintw(win,3,win->_maxx/4+37,"%d",computador->memoria[0]);
                break;
            case 18:
                ended = 1;
                actualizarFlags(win,computador);
                break;

            default:
                break;
        }
        sleep(1);
        mvwprintw(win,win->_maxy/2+3,win->_maxx/2+21,"Almacenar");
        mostrarDatos(win,computador);
        mvwprintw(win,computador->PC+6,3,"->");
        mvwprintw(win,anteriorX,3,"  ");
        anteriorX =computador->PC+6;
        wrefresh(win);
        if(ch != '0'){
          ch = wgetch(win);
          if(ch == '1'){
              computador->PC++;
          }else if( ch == '2'){
              mostrarDatos(win,computador);
              wrefresh(win);
              break;
          }
        }
        else{
          computador->PC++;
        }sleep(1);
        mvwprintw(win,win->_maxy/2+3,win->_maxx/2+21,"Almacenar");
    }
    iniciarComputador(computador);
    mostrarDatos(win,computador);
    wrefresh(win);
}
/*=========================================
Objetivo: Ejecucion general del segundo programa
Input: win(ventana),computador(estructura)
Output: Ejecucion del programa dos
=========================================*/
void programaDos(WINDOW * win, struct Computador *computador){
    computador->IR = 1;
    int regY = win->_maxy/2+3;
    int regX = win->_maxx/4 + 20;
    mostrarProgramaDos(win);
    menuPrograma(win,computador);
    ejecutarProgramaDos(win,computador);
    limpiarArea(win,computador,regY,30,regX,28);
    wrefresh(win);
}
/*=========================================
Objetivo: Ejecuta las instrucciones del programa tres
Input: win(ventana),computador(estructura)
Output: Ejecucion del programa tres
=========================================*/
void ejecutarProgramaTres(WINDOW * win, struct Computador *computador){
    int ended = 0;
    int ch = 0;
    int screenChanged = 1;
    int anteriorX = -1;
    computador->PC = 1;
    while(!ended){
        imprimirEtapaFetch(win,computador);
        switch (computador->PC){
            case 2:
                imprimirFetch(win,computador,9,0,0);
                mvwprintw(win,2,win->_maxx/4+20,"Ingrese el numero uno: ");
                actualizarFlags(win,computador);
                break;
            case 3:
                imprimirFetch(win,computador,11,0,0);
                mvwprintw(win,computador->PC+11,3,"->");
                mvwprintw(win,anteriorX,3,"  ");
                wrefresh(win);
                copiar(&computador->memoria[0],recibirNumero(win,computador,6,0));
                actualizarFlags(win,computador);
                break;
            case 4:
                imprimirFetch(win,computador,9,0,0);
                mvwprintw(win,3,win->_maxx/4+20,"Ingrese el numero dos: ");
                actualizarFlags(win,computador);
                break;
            case 5:
                imprimirFetch(win,computador,11,0,30);
                mvwprintw(win,computador->PC+11,3,"->");
                mvwprintw(win,anteriorX,3,"  ");
                wrefresh(win);
                copiar(&computador->memoria[1],recibirNumero(win,computador,6,1));
                actualizarFlags(win,computador);
                break;
            case 6:
                imprimirFetch(win,computador,0,0,36);
                copiar(&computador->DI,1);
                actualizarFlags(win,computador);
                break;
            case 8:
                imprimirFetch(win,computador,8,36,0);
                DAEMLM(&computador->EDX,computador->memoria[0],computador->DI);
                actualizarFlags(win,computador);
                break;
            case 9:
                imprimirFetch(win,computador,4,0,33);
                comparar(computador->EDX,0,&computador->ZF,&computador->SF,&computador->CF,&computador->OF);
                break;
            case 10:
                imprimirFetch(win,computador,14,0,15);
                saltoIgual(computador->EDX,0,&computador->PC,15);
                break;(win,computador);
            case 11:
                imprimirFetch(win,computador,3,0,36);
                aumentar(&computador->DI);
                actualizarFlags(win,computador);
                break;
            case 12:
                imprimirFetch(win,computador,4,0,36);
                comparar(computador->DI,computador->memoria[0],&computador->ZF,&computador->SF,&computador->CF,&computador->OF);
                actualizarFlags(win,computador);
                break;
            case 13:
                imprimirFetch(win,computador,6,0,18);
                saltoMayorIgual(computador->DI,computador->memoria[0],&computador->PC,18);
                actualizarFlags(win,computador);
                break;
            case 14:
                imprimirFetch(win,computador,12,0,7);
                computador->PC = 7;
                actualizarFlags(win,computador);
                break;
            case 16:
                imprimirFetch(win,computador,7,36,0);
                sumar(&computador->memoria[2],computador->DI);
                actualizarFlags(win,computador);
                break;
            case 17:
                imprimirFetch(win,computador,3,0,36);
                aumentar(&computador->DI);
                actualizarFlags(win,computador);
                break;
            case 18:
                imprimirFetch(win,computador,12,0,7);
                computador->PC = 7;
                actualizarFlags(win,computador);
                break;
            case 19:
                imprimirFetch(win,computador,4,0,0);
                comparar(computador->memoria[2],computador->memoria[1],&computador->ZF,&computador->SF,&computador->CF,&computador->OF);
                actualizarFlags(win,computador);
                break;;
             case 20:
                imprimirFetch(win,computador,6,0,0);
                saltoNoIgual(computador->memoria[2],computador->memoria[1],&computador->PC,39);
                actualizarFlags(win,computador);
                break;
              case 21:
                imprimirFetch(win,computador,4,0,36);
                copiar(&computador->DI,1);
                actualizarFlags(win,computador);
                break;
              //Segunda pantalla
              case 23:
                imprimirFetch(win,computador,8,0,36);
                DAEMLM(&computador->EDX,computador->memoria[1],computador->DI);
                actualizarFlags(win,computador);
                break;
              case 24:
                imprimirFetch(win,computador,4,33,0);
                comparar(computador->EDX,0,&computador->ZF,&computador->SF,&computador->CF,&computador->OF);
                actualizarFlags(win,computador);
                break;
              case 25:
                imprimirFetch(win,computador,14,0,30);
                saltoIgual(computador->EDX,0,&computador->PC,30);
                actualizarFlags(win,computador);
                break;(win,computador);
              case 26:
                imprimirFetch(win,computador,3,0,36);
                aumentar(&computador->DI);
                actualizarFlags(win,computador);
                break;
             case 27:
                imprimirFetch(win,computador,4,0,36);
                comparar(computador->DI,computador->memoria[1],&computador->ZF,&computador->SF,&computador->CF,&computador->OF);
                actualizarFlags(win,computador);
                break;;
             case 28:
                imprimirFetch(win,computador,6,0,34);
                saltoMayorIgual(computador->DI,computador->memoria[1],&computador->PC,34);
                actualizarFlags(win,computador);
                break;
              case 29:
                imprimirFetch(win,computador,12,0,22);
                computador->PC = 22;
                actualizarFlags(win,computador);
                break;
              case 31:
                imprimirFetch(win,computador,7,36,0);
                sumar(&computador->memoria[3],computador->DI);
                actualizarFlags(win,computador);
                break;
              case 32:
                imprimirFetch(win,computador,3,0,36);
                aumentar(&computador->DI);
                actualizarFlags(win,computador);
                break;
              case 33:
                imprimirFetch(win,computador,12,0,22);
                computador->PC = 22;
                actualizarFlags(win,computador);
                break;
              case 35:
                imprimirFetch(win,computador,4,0,0);
                comparar(computador->memoria[3],computador->memoria[0],&computador->ZF,&computador->SF,&computador->CF,&computador->OF);
                actualizarFlags(win,computador);
                break;;
               case 36:
                imprimirFetch(win,computador,5,0,39);
                saltoNoIgual(computador->memoria[3],computador->memoria[0],&computador->PC,39);
                actualizarFlags(win,computador);
                break;
              case 37:
                imprimirFetch(win,computador,9,0,0);
                mvwprintw(win,4,win->_maxx/4+20,"Son amigos");
                actualizarFlags(win,computador);
                computador->PC = 40;
                break;
              case 38:
                imprimirFetch(win,computador,12,0,41);
                computador->PC = 41;
                actualizarFlags(win,computador);
                break;
              case 40:
                imprimirFetch(win,computador,9,0,0);
                mvwprintw(win,4,win->_maxx/4+20,"No son amigos");
                actualizarFlags(win,computador);
                break;
              case 41:
                ended=1;   
                break;
              default:
                break;
        }
        sleep(1);
        mvwprintw(win,win->_maxy/2+3,win->_maxx/2+21,"Almacenar");
        mostrarDatos(win,computador);
        mvwprintw(win,anteriorX,3,"  ");
        if(computador->PC > 21 && screenChanged){
           limpiarArea(win,computador,2,36,2,40);
           wrefresh(win);
            mostrarProgramaTresSegundo(win);
            screenChanged = 0;
        }
        if(computador->PC <= 21){
          mvwprintw(win,computador->PC+11,3,"->");
          anteriorX =computador->PC+11;
        }
        else{
          mvwprintw(win,computador->PC-20,3,"->");
          anteriorX =computador->PC-20;
        }
        wrefresh(win);
        if(ch != '0'){
          ch = wgetch(win);
          if(ch == '1'){
              computador->PC++;
          }else if( ch == '2'){
              mostrarDatos(win,computador);
              wrefresh(win);
              break;
          }
        }
        else if (ended == 0){
          computador->PC++;
        }
    }
    iniciarComputador(computador);
    mostrarDatos(win,computador);
    wrefresh(win);
}
/*=========================================
Objetivo: Ejecucion general del tercer programa
Input: win(ventana),computador(estructura)
Output: Programa tres ejecutado
=========================================*/
void programaTres(WINDOW * win, struct Computador *computador){
    computador->IR = 1;
    int regY = win->_maxy/2+3;
    int regX = win->_maxx/4 + 20;
    mostrarProgramaTres(win);
    menuPrograma(win,computador);
    ejecutarProgramaTres(win,computador);
    limpiarArea(win,computador,win->_maxy/2+3,30,win->_maxx/4 + 20,28);
    wrefresh(win);
}
/*=========================================
Objetivo: Despliega el menu principal
Input: win(ventana),computador(estructura)
Output: Opcion seleccionada ejecutada
=========================================*/
void menuPrincipal(WINDOW * win, struct Computador *computador){
    int regY = win->_maxy/2 + 3;
    int regX = win->_maxx/4 +  20;
    int repeat = 1;
    int option = 0;
    while(repeat){
        wattron(win,COLOR_PAIR(2));
        mvwprintw(win,regY,regX,"1- Programa #1");
        mvwprintw(win,regY+1,regX,"2- Programa #2");
        mvwprintw(win,regY+2,regX,"3- Programa #3");
        wattroff(win,COLOR_PAIR(2));
        mvwprintw(win,regY+3,regX,"4- Salir");
        refresh();
        option = wgetch(win);
        if (option == '1'){
            programaUno(win,computador);
        }
        else if (option == '2'){
            programaDos(win,computador);
        }
        else if (option == '3'){
            programaTres(win,computador);
        }
        else if (option == '4'){
            return;
        }
        else{
            wattron(win,COLOR_PAIR(parRegs));
            mvwprintw(win,regY+5,regX,"Opcion invalida");
            wattroff(win,COLOR_PAIR(parRegs));
        }
        limpiarArea(win,computador,2,36,2,40); //Limpia la entrada de datos
        limpiarArea(win,computador,2,18,54,34); //limpia la salida de datos
        wrefresh(win);
    }

}
/*=========================================
Objetivo: Se inician los procesos principales
Input: computador(estructura)
Output: Proceso general del programa 
=========================================*/
void comenzarProceso(struct Computador *computador){
    initscr(); //Inicia la pantalla
    noecho();
    curs_set(0);
    int maxY,maxX;
    getmaxyx(stdscr,maxY,maxX);

    WINDOW * win = newwin(maxY,maxX,0,0);
    box(win,0,0);
    dibujarInterfaz(win,maxY,maxX);
    mostrarDatos(win,computador);
    refresh();  //Refresca la pantalla con lo que hay en memoria
    menuPrincipal(win,computador);
    wrefresh(win);
    int c = getch();
    endwin(); //Finaliza la pantalla
}
