#include "colores.c"
//////////////////////////////////////////////////////////////////////////////////////////////////////
/*
Objetivo: Imprimir el codigo del programa uno
Input: win(pantalla en la que se debe imprimir)
Output: Programa uno desplegado en la interfaz
*/
void mostrarProgramaUno(WINDOW * win){
        mvwprintw(win,2,5,".DATOS");
        mvwprintw(win,3,5,"numero");
        mvwprintw(win,4,5,"resultado");
        mvwprintw(win,5,5,"solicitud");
        mvwprintw(win,6,5,"msgResultado");
        mvwprintw(win,7,5,".CODIGO");
        mvwprintw(win,8,5,".INICIO");
        mvwprintw(win,9,9,"[resultado],");
        mvwprintw(win,11,12,"[numero]");
        mvwprintw(win,10,12,"solicitud");
        mvwprintw(win,12,5,"cicloFactorial:");
        mvwprintw(win,13,15,",[numero]");
        mvwprintw(win,14,15,",[resultado]");
        mvwprintw(win,16,13,"[resultado],");
        mvwprintw(win,17,15,",[numero]");
        mvwprintw(win,19,13,"[numero],");
        mvwprintw(win,21,13,"cicloFactorial");
        mvwprintw(win,22,9,"mstrnl");
        mvwprintw(win,23,9,"pnrCdn msgResultado");
        mvwprintw(win,24,9,"mstrNtr [resultado]");
        mvwprintw(win,25,9,".FIN");
        wattron(win,COLOR_PAIR(parMem)); //Palabras reservadas
        mvwprintw(win,3,12,"db");
        mvwprintw(win,4,15,"db");
        mvwprintw(win,5,15,"db");
        mvwprintw(win,6,18,"db");
        mvwprintw(win,9,5,"cpr");
        mvwprintw(win,10,5,"pnrCdn");
        mvwprintw(win,11,5,"tmrNtr");
        mvwprintw(win,13,9,"cpr");
        mvwprintw(win,14,9,"cpr");
        mvwprintw(win,15,9,"mult");
        mvwprintw(win,16,9,"cpr");
        mvwprintw(win,17,9,"cpr");
        mvwprintw(win,18,9,"dis");
        mvwprintw(win,19,9,"cpr");
        mvwprintw(win,20,9,"cprr");
        mvwprintw(win,21,9,"sni");
        wattroff(win,COLOR_PAIR(parMem));
        wattron(win,COLOR_PAIR(parIO)); //Registros
        mvwprintw(win,13,13,"AX");
        mvwprintw(win,14,13,"BX");
        mvwprintw(win,15,14,"BX");
        mvwprintw(win,16,25,"AX");
        mvwprintw(win,17,13,"AX");
        mvwprintw(win,18,13,"AX");
        mvwprintw(win,19,22,"AX");
        mvwprintw(win,20,14,"AX");
        wattroff(win,COLOR_PAIR(parIO)); //Variables
        wattron(win,COLOR_PAIR(parPort));  //Strings o chars
        mvwprintw(win,3,15,"1");
        mvwprintw(win,4,18,"1");
        mvwprintw(win,5,18,"\'Ingrese el dato: \',0");
        mvwprintw(win,6,21,"\'El resultado es: \',0");
        mvwprintw(win,9,21,"1");
        mvwprintw(win,20,16,",1");
        wattroff(win,COLOR_PAIR(parPort));
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
/*
Objetivo: Imprimir el codigo del programa dos
Input: win(pantalla en la que se debe imprimir)
Output: Programa dos desplegado en la interfaz
*/
void mostrarProgramaDos(WINDOW * win){
    mvwprintw(win,2,5,".DATOS");
    mvwprintw(win,3,5,"solicita");
    mvwprintw(win,4,5,".NDATOS");
    mvwprintw(win,5,5,"cadena");
    mvwprintw(win,6,5,".CODIGO");
    mvwprintw(win,7,5,".INICIO");
    mvwprintw(win,8,5,"pnrCdn");
    mvwprintw(win,8,15,"solicita");
    mvwprintw(win,9,5,"tmrCdn");
    mvwprintw(win,9,12,"[cadena]");
    mvwprintw(win,10,11,",[cadena]");
    mvwprintw(win,11,5,"cicloMinimizar:");
    mvwprintw(win,13,10,"saltarCorreccion");
    mvwprintw(win,15,8,"mostrarCadena");
    mvwprintw(win,17,5,"saltarCorreccion:");
    mvwprintw(win,19,9,"cicloMinimizar");
    mvwprintw(win,20,5,"mostrarCadena:");
    //mvwprintw(win,21,15,",[cadena]");
    mvwprintw(win,21,9,"pnrCdn cadena");
    mvwprintw(win,22,9,".FIN");
    wattron(win,COLOR_PAIR(parMem)); //Palabras reservadas
    mvwprintw(win,3,14,"db");
    mvwprintw(win,5,12,"resb");
    mvwprintw(win,10,5,"CPR");
    mvwprintw(win,12,5,"cmprr");
    mvwprintw(win,13,5,"smai");
    mvwprintw(win,14,5,"cmprr");
    mvwprintw(win,15,5,"si");
    mvwprintw(win,16,5,"sum");
    mvwprintw(win,18,9,"aum");
    mvwprintw(win,19,5,"slt");
    wattroff(win,COLOR_PAIR(parMem));
    wattron(win,COLOR_PAIR(parIO)); //Registros
    mvwprintw(win,10,9,"AX");
    mvwprintw(win,12,11,"[AX]");
    mvwprintw(win,14,11,"[AX]");
    mvwprintw(win,16,9,"[AX]");
    mvwprintw(win,18,13,"AX");
    wattroff(win,COLOR_PAIR(parIO));
    wattron(win,COLOR_PAIR(parPort)); //Variables
    mvwprintw(win,3,17,"\'Ingrese una cadena: \',0");
    mvwprintw(win,5,17,"300");
    mvwprintw(win,12,15,",\'a\'");
    mvwprintw(win,14,15,",0");
    mvwprintw(win,16,14,",20h");
    wattroff(win,COLOR_PAIR(parPort));
    }
//////////////////////////////////////////////////////////////////////////////////////////////////////
/*
Objetivo: Imprimir el codigo del programa tres
Input: win(pantalla en la que se debe imprimir)
Output: Programa tres desplegado en la interfaz
*/
void mostrarProgramaTres(WINDOW * win){
    mvwprintw(win,2,5,".DATOS");
    mvwprintw(win,3,5,"numeroUno");
    mvwprintw(win,4,5,"numeroDos");
    mvwprintw(win,5,5,"sumaUno");
    mvwprintw(win,6,5,"sumaDos");
    mvwprintw(win,7,5,"solUno");
    mvwprintw(win,8,5,"solDos");
    mvwprintw(win,9,5,"son");
    mvwprintw(win,10,5,"noSon");
    mvwprintw(win,11,5,".CODIGO");
    mvwprintw(win,12,5,".INICIO");
    mvwprintw(win,13,5,"pnrCdn");
    mvwprintw(win,13,13,"solUno");
    mvwprintw(win,14,5,"tmrNtr");
    mvwprintw(win,14,12,"[numeroUno]");
    mvwprintw(win,15,5,"pnrCdn");
    mvwprintw(win,15,13,"solDos");
    mvwprintw(win,16,5,"tmrNtr");
    mvwprintw(win,18,5,"evaluarCicloUno: ");
    mvwprintw(win,19,12,"numeroUno");
    mvwprintw(win,21,8,"esMultiploUno");
    mvwprintw(win,23,13,",numeroUno");
    mvwprintw(win,24,10,"sigueUno");
    mvwprintw(win,25,9,"evaluarCicloUno");
    mvwprintw(win,26,5,"esMultiploUno:");
    mvwprintw(win,27,9,"[sumaUno]");
    mvwprintw(win,29,10,"evaluarCicloUno");
    mvwprintw(win,30,5,"sigueUno:");
    mvwprintw(win,31,10,"[sumaUno],[numeroDos]");
    mvwprintw(win,32,9,"noSonA");
    wattron(win,COLOR_PAIR(parMem)); //Palabras reservadas
    mvwprintw(win,3,15,"dw");
    mvwprintw(win,4,15,"dw");
    mvwprintw(win,5,13,"dw");
    mvwprintw(win,6,13,"dw");
    mvwprintw(win,7,12,"db");
    mvwprintw(win,8,12,"db");
    mvwprintw(win,9,9,"db");
    mvwprintw(win,10,11,"db");
    mvwprintw(win,17,5,"cpr");
    mvwprintw(win,19,5,"DAEMLM");
    mvwprintw(win,20,5,"cmprr");
    mvwprintw(win,21,5,"si");
    mvwprintw(win,22,5,"aum");
    mvwprintw(win,23,5,"cmprr");
    mvwprintw(win,24,5,"smai");
    mvwprintw(win,25,5,"slt");
    mvwprintw(win,27,5,"sum");
    mvwprintw(win,28,5,"aum");
    mvwprintw(win,29,5,"slt");
    mvwprintw(win,31,5,"cmprr");
    mvwprintw(win,32,5,"sni");
    mvwprintw(win,33,5,"cpr");
    wattroff(win,COLOR_PAIR(parMem));
    wattron(win,COLOR_PAIR(parIO)); //Registros
    mvwprintw(win,17,9,"DI");
    mvwprintw(win,19,21,",DI");
    mvwprintw(win,20,11,"DX");
    mvwprintw(win,22,9,"DI");
    mvwprintw(win,23,11,"DI");
    mvwprintw(win,27,19,",DI");
    mvwprintw(win,28,9,"DI");
    mvwprintw(win,33,9,"DI,");
    wattroff(win,COLOR_PAIR(parIO));
    wattron(win,COLOR_PAIR(parPort)); //Variables
    mvwprintw(win,3,18,"0");
    mvwprintw(win,4,18,"0");
    mvwprintw(win,5,16,"0");
    mvwprintw(win,6,16,"0");
    mvwprintw(win,20,13,",0");
    mvwprintw(win,7,15,"\'Ingrese el numero uno: \',0");
    mvwprintw(win,8,15,"\'Ingrese el numero dos: \',0");
    mvwprintw(win,9,12,"\'Son amigos\',0");
    mvwprintw(win,10,14,"\'No son amigos\',0");
    mvwprintw(win,17,12,",1");
    mvwprintw(win,33,12,"1");
    wattroff(win,COLOR_PAIR(parPort));
    }
void mostrarProgramaTresSegundo(WINDOW * win){
    mvwprintw(win,2,5,"evaluarCicloDos:");
    mvwprintw(win,3,12,"numeroDos");
    mvwprintw(win,5,8,"esMultiploDos");
    mvwprintw(win,8,10,"sigueDos");
    mvwprintw(win,9,9,"evaluarCicloDos");
    mvwprintw(win,10,5,"esMultiploDos:");
    mvwprintw(win,11,9,"[sumaDos]");
    mvwprintw(win,13,9,"evaluarCicloDos");
    mvwprintw(win,14,5,"sigueDos: ");
    mvwprintw(win,15,11,"[sumaDos],[numeroUno]");
    mvwprintw(win,16,9,"noSonA");
    mvwprintw(win,17,5,"mstrr son");
    mvwprintw(win,18,9,"fin");
    mvwprintw(win,19,5,"noSonA:");
    mvwprintw(win,20,5,"mstrr noSon");
    mvwprintw(win,21,5,"fin: ");
    mvwprintw(win,22,5,".EXIT");
    wattron(win,COLOR_PAIR(parMem)); //Palabras reservadas
    mvwprintw(win,3,5,"DAEMLM");
    mvwprintw(win,4,5,"cmprr");
    mvwprintw(win,5,5,"si");
    mvwprintw(win,6,5,"aum");
    mvwprintw(win,7,5,"cmprr");
    mvwprintw(win,8,5,"smai");
    mvwprintw(win,9,5,"slt");
    mvwprintw(win,11,5,"sum");
    mvwprintw(win,12,5,"aum");
    mvwprintw(win,13,5,"slt");
    mvwprintw(win,15,5,"cmprr");
    mvwprintw(win,16,5,"sni");
    mvwprintw(win,18,5,"slt");
    wattroff(win,COLOR_PAIR(parMem));
    wattron(win,COLOR_PAIR(parIO)); //Registros
    mvwprintw(win,3,22,",DI");
    mvwprintw(win,4,11,"DX,");
    mvwprintw(win,6,9,"DI");
    mvwprintw(win,7,11,"DI,");
    mvwprintw(win,7,15,"numeroDos");
    mvwprintw(win,11,19,",DI");
    mvwprintw(win,12,9,"DI");
    wattroff(win,COLOR_PAIR(parIO));


    wattron(win,COLOR_PAIR(parPort)); //Variables
    mvwprintw(win,4,14,"0");
    wattroff(win,COLOR_PAIR(parPort));
}
