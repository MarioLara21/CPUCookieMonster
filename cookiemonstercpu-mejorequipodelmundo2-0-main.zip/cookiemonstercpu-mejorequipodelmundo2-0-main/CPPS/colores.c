#include <ncurses.h>
#define titulos 1
#define parIO 2
#define parRegs 3
#define parFlags 4
#define parMenu 5
#define parFetch 12
#define parPort 13
#define parMem 14
#define colIO 8
#define colRegs 9
#define colFlags 10
#define colMenu 11
#define colFetch  12
#define colPort 13
#define colMem 14
/*
Objetivo: Iniciar los colores que se van a utilizar
Input: N/A
Output: Colores inicializados en variables
*/
void initColors(){
    init_color(colIO,122,565,980);
    init_color(colRegs,956,0,631);
    init_color(colFlags,392,309,811);
    init_color(colMenu,686,321,909);
    init_color(colFetch,543,250,392);
    init_color(colPort,250,878,815);
    init_color(colMem,834,207,936);
}
/*
Objetivo: Crear los pares de colores para la interfaz
Input: N/A
Output: Pares de colores inicializados en variables
*/
void initPairs(){
    init_pair(titulos, COLOR_WHITE, COLOR_BLACK);
    init_pair(parIO, colIO, COLOR_BLACK);
    init_pair(parRegs, colRegs, COLOR_BLACK);
    init_pair(parFlags, colFlags, COLOR_BLACK);
    init_pair(parMenu, colMenu, COLOR_BLACK);
    init_pair(parFetch, colFetch, COLOR_BLACK);
    init_pair(parPort, colPort, COLOR_BLACK);
    init_pair(parMem, colMem, COLOR_BLACK);
}