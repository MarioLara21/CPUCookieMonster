#include <stdio.h>

typedef struct Computador{
    int PC;
    int IR;
    int OF;
    int ZF;
    int SF;
    int CF;
    int DI;
    int SI;
    int EAX;
    int EBX;
    int ECX;
    int EDX;
    int contFetch; // Esto es para realizar el cicloFetch
    int autoMatic;
    int memoria[30];
    int encendido;
}computador;
